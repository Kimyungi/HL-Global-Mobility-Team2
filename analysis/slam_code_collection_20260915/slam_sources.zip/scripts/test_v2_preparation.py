"""Preparation launch structure; never starts GPS, cameras, CAN or ROS processes."""
import importlib.util
from pathlib import Path

import pytest
from launch import LaunchContext
from launch.actions import DeclareLaunchArgument, ExecuteProcess
from stack_gps import persistent_service

ROOT = Path(__file__).resolve().parents[1]


def module():
    path = ROOT / 'src/adas_mgm/launch/REAL_VEHICLE_integration_v2_drive.launch.py'
    spec = importlib.util.spec_from_file_location('prepare_drive', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def context(mod, tmp_path):
    ctx = LaunchContext()
    for item in mod.generate_launch_description().entities:
        if isinstance(item, DeclareLaunchArgument):
            item.execute(ctx)
    ctx.launch_configurations['run_log_dir'] = str(tmp_path / 'run')
    ctx.launch_configurations['rviz'] = 'false'
    return ctx


def test_show_args_and_invalid_token_do_not_start_receiver(monkeypatch, tmp_path):
    monkeypatch.setattr(persistent_service, 'ensure_running', lambda *a, **kw: pytest.fail('hardware touched'))
    mod = module()
    ctx = context(mod, tmp_path)
    with pytest.raises(RuntimeError, match='token required'):
        mod.start_stack(ctx)
    assert not (tmp_path / 'run').exists()


def test_drive_reuses_persistent_link_and_does_not_own_rtcm_child(monkeypatch, tmp_path):
    mod = module()
    monkeypatch.setenv('FMA_V2_WORKSPACE', str(ROOT))
    # Build a minimal isolated install share for the launch import; only return actions.
    share = ROOT / 'install_v2/adas_mgm/share/adas_mgm'
    monkeypatch.setattr(mod, 'get_package_share_directory', lambda _: str(share))
    monkeypatch.setattr(mod, 'check_lidar_devices', lambda: None)
    calls = []
    monkeypatch.setattr(persistent_service, 'ensure_running', lambda cfg, script: calls.append((cfg, script)))
    ctx = context(mod, tmp_path)
    ctx.launch_configurations['REAL_VEHICLE_CONFIRM'] = 'I_UNDERSTAND_THIS_ENABLES_REAL_CAN_TX'
    actions = mod.start_stack(ctx)
    assert len(calls) == 1 and calls[0][0]['start_relay'] is True
    assert ctx.launch_configurations['gps_link_mode'] == 'persistent'
    assert not any('rtcm_server.py' in str(getattr(a, 'cmd', '')) for a in actions if isinstance(a, ExecuteProcess))


def test_stop_command_cannot_shut_down_gps_and_prepare_is_explicit():
    script = (ROOT / 'scripts/v2').read_text()
    stop = script.split('  stop)', 1)[1].split(';;', 1)[0]
    assert '/operator/stop' in stop and 'persistent_service' not in stop
    assert 'gps-off) V2_GPS_ACTION=stop' in script
    assert 'gps-start) V2_GPS_ACTION=start' in script


def test_prepare_runs_full_wait_go_launcher():
    script = (ROOT / 'scripts/v2').read_text()
    assert '  prepare|drive)' in script
    assert 'REAL_VEHICLE_integration_v2_drive.launch.py' in script


def test_missing_lidar_aborts_before_hardware(monkeypatch,tmp_path):
    mod=module()
    monkeypatch.setenv('FMA_V2_WORKSPACE',str(ROOT))
    monkeypatch.setattr(mod,'get_package_share_directory',lambda _: str(ROOT/'install_v2/adas_mgm/share/adas_mgm'))
    monkeypatch.setattr(mod.os,'access',lambda *a:False)
    monkeypatch.setattr(persistent_service,'ensure_running',lambda *a,**kw:pytest.fail('receiver touched'))
    ctx=context(mod,tmp_path)
    ctx.launch_configurations['REAL_VEHICLE_CONFIRM']='I_UNDERSTAND_THIS_ENABLES_REAL_CAN_TX'
    with pytest.raises(RuntimeError,match='라이다 장치'):
        mod.start_stack(ctx)
    assert not (tmp_path/'run').exists()


@pytest.mark.parametrize('backend', ['native', 'python'])
def test_compute_trial_default_and_override_reach_avoid(monkeypatch, tmp_path, backend):
    from launch_ros.actions import Node
    from launch_ros.utilities import evaluate_parameters
    mod = module()
    ctx = context(mod, tmp_path)
    assert ctx.launch_configurations['avoid_compute_backend'] == 'native'
    ctx.launch_configurations['avoid_compute_backend'] = backend
    ctx.launch_configurations['REAL_VEHICLE_CONFIRM'] = 'I_UNDERSTAND_THIS_ENABLES_REAL_CAN_TX'
    monkeypatch.setenv('FMA_V2_WORKSPACE', str(ROOT))
    monkeypatch.setattr(mod, 'check_lidar_devices', lambda: None)
    monkeypatch.setattr(persistent_service, 'ensure_running', lambda *a: None)
    actions = mod.start_stack(ctx)
    for action in actions:
        if isinstance(action, DeclareLaunchArgument):
            action.execute(ctx)
    avoid = next(a for a in actions if isinstance(a, Node) and a.node_package == 'stack_avoid')
    params = evaluate_parameters(ctx, avoid._Node__parameters)[1]
    assert params['avoid.compute_backend'] == backend
    assert (tmp_path / 'run' / 'avoid_compute_backend.txt').read_text().strip() == backend


def test_missing_native_backend_aborts_before_devices(monkeypatch, tmp_path):
    from stack_avoid import compute_backend
    mod = module()
    ctx = context(mod, tmp_path)
    ctx.launch_configurations['REAL_VEHICLE_CONFIRM'] = 'I_UNDERSTAND_THIS_ENABLES_REAL_CAN_TX'
    def fail(_):
        raise RuntimeError('native unavailable')
    monkeypatch.setattr(compute_backend, 'compute_functions', fail)
    monkeypatch.setattr(mod, 'check_lidar_devices', lambda: pytest.fail('hardware touched'))
    monkeypatch.setattr(persistent_service, 'ensure_running', lambda *a: pytest.fail('receiver touched'))
    with pytest.raises(RuntimeError, match='native unavailable'):
        mod.start_stack(ctx)
    assert not (tmp_path / 'run').exists()


def test_main_gap_trial_selects_original_config_and_no_native_dependency(monkeypatch, tmp_path):
    from launch_ros.actions import Node
    from launch_ros.utilities import evaluate_parameters
    from launch.utilities import perform_substitutions
    from stack_avoid import compute_backend
    mod = module()
    ctx = context(mod, tmp_path)
    ctx.launch_configurations['avoid_planner_mode'] = 'main_gap'
    ctx.launch_configurations['v_base'] = '1.0'
    ctx.launch_configurations['v_avoid'] = '0.6'
    ctx.launch_configurations['REAL_VEHICLE_CONFIRM'] = 'I_UNDERSTAND_THIS_ENABLES_REAL_CAN_TX'
    monkeypatch.setenv('FMA_V2_WORKSPACE', str(ROOT))
    monkeypatch.setattr(mod, 'check_lidar_devices', lambda: None)
    monkeypatch.setattr(persistent_service, 'ensure_running', lambda *a: None)
    monkeypatch.setattr(compute_backend, 'compute_functions', lambda *a: pytest.fail('main must not load cubic backend'))
    actions = mod.start_stack(ctx)
    for action in actions:
        if isinstance(action, DeclareLaunchArgument):
            action.execute(ctx)
    avoid = next(a for a in actions if isinstance(a, Node) and a.node_package == 'stack_avoid')
    assert perform_substitutions(ctx, [avoid.node_executable]) == 'main_gap_trial'
    params = evaluate_parameters(ctx, avoid._Node__parameters)
    assert str(params[0]).endswith('params_main_gap.yaml')
    assert params[1]['avoid.require_mgm_active'] is True
    assert params[1]['lidar_mount.forward_angle_deg'] == pytest.approx(87.)
    assert params[1]['target_speed_mps'] == 1.0
    mgm = next(a for a in actions if isinstance(a, Node) and a.node_package == 'adas_mgm')
    speed_params = {k: v for k, v in mgm._Node__parameters[1].items()
                    if perform_substitutions(ctx, k) in ('v_base', 'v_avoid')}
    mgm_params = evaluate_parameters(ctx, [speed_params])[0]
    assert mgm_params['v_base'] == 1.0 and mgm_params['v_avoid'] == .6
    assert (tmp_path/'run'/'avoid_planner_mode.txt').read_text().strip() == 'main_gap'
    assert (tmp_path/'run'/'avoid_compute_backend.txt').read_text().strip() == 'main_gap_python'


@pytest.mark.parametrize('backend', ['python', 'native'])
def test_three_point_path_trial_and_zone_speed_reach_runtime(monkeypatch, tmp_path, backend):
    from launch_ros.actions import Node
    from launch_ros.utilities import evaluate_parameters
    from launch.utilities import perform_substitutions
    mod = module()
    ctx = context(mod, tmp_path)
    ctx.launch_configurations.update(avoid_planner_mode='main_gap_path',
        avoid_compute_backend=backend, v_base='2.0', v_avoid='1.0',
        REAL_VEHICLE_CONFIRM='I_UNDERSTAND_THIS_ENABLES_REAL_CAN_TX')
    monkeypatch.setenv('FMA_V2_WORKSPACE', str(ROOT))
    monkeypatch.setattr(mod, 'check_lidar_devices', lambda: None)
    monkeypatch.setattr(persistent_service, 'ensure_running', lambda *a: None)
    actions = mod.start_stack(ctx)
    for action in actions:
        if isinstance(action, DeclareLaunchArgument):
            action.execute(ctx)
    avoid = next(a for a in actions if isinstance(a, Node) and a.node_package == 'stack_avoid')
    assert perform_substitutions(ctx, [avoid.node_executable]) == 'main_gap_path_trial'
    params = evaluate_parameters(ctx, avoid._Node__parameters)
    assert str(params[0]).endswith('params_main_gap.yaml')
    assert params[1]['avoid.compute_backend'] == backend
    assert params[1]['target_speed_mps'] == 2.0
    assert params[1]['avoid.require_mgm_active'] is True
    mgm = next(a for a in actions if isinstance(a, Node) and a.node_package == 'adas_mgm')
    selected = {k:v for k,v in mgm._Node__parameters[1].items()
                if perform_substitutions(ctx,k) in ('v_base','v_avoid')}
    assert evaluate_parameters(ctx,[selected])[0] == dict(v_base=2.0,v_avoid=1.0)
    assert (tmp_path/'run'/'avoid_planner_mode.txt').read_text().strip() == 'main_gap_path'
    assert (tmp_path/'run'/'avoid_compute_backend.txt').read_text().strip() == backend
