/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: rtGetNaN.h
 *
 * Code generated for Simulink model 'ADAS_MGR2'.
 *
 * Model version                  : 1.88
 * Simulink Coder version         : 26.1 (R2026a) 20-Nov-2025
 * C/C++ source code generated on : Mon Aug 24 16:57:32 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef rtGetNaN_h_
#define rtGetNaN_h_
#include "rt_nonfinite.h"
#include "rtwtypes.h"

extern real_T rtGetNaN(void);
extern real32_T rtGetNaNF(void);

#endif                                 /* rtGetNaN_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
