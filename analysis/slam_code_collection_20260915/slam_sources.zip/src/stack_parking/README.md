# stack_parking — 차량/GPS 측위와 LiDAR 맵 기반 주차

`lidar_fusion_v2`의 4-LiDAR nearest-wins 스캔을 주차 전용 cloud로 변환해
SLAM·공간 탐지·경로 제어에 사용한다. 주차 결과는 `/perception/parking`으로
MGM에 넘기며 `/adas/target_ref`는 MGM만 발행한다.

## 파이프라인

1. **SLAM** — 전·후 cloud를 timestamp로 한 쌍씩 소비하거나 통합 cloud를
   받아 최대 10Hz로 위치와 맵을 갱신한다. `parking_map` 시작 자세는 `(0,0,0)`이다.
2. **MAPPING** — `space_found=false`인 동안 endpoint map을 누적한다. dSPACE
   `VehicleVector.v/str`의 자전거 모델로 위치를 예측하고,
   RTK FIXED `GpsPath`의 새 delta를 innovation gate 뒤 x/y drift 보정에 쓴다.
   기본 설정에서 맵 정합과 `VehicleVector.x/y/yaw`, 직접 IMU 입력은 사용하지 않는다.
3. `GpsPath.parking_zone` 상승 에지와 `parking_mode`에서 평행(1자)/직각(T자),
   좌/우를 결정한다. 양쪽 정적 경계가 있는 gap을 3 frame 연속 확인한다. 직각 주차는 gap 내부 후면
   벽 지지점까지 요구한다. 측면 경계 후보는 최대 3m까지 탐색하며, 직각 주차의 후면 벽
   깊이는 이 상한과 별도로 `perpendicular_min_depth_m`을 적용한다. 별도 평행주차 시험 노드의
   초기 고정 벽 탐색도 같은 3m 상한을 사용하며, 공통 SLAM 맵의 2cm 재관측 정책을 그대로 받는다.
4. **LOCALIZATION** — 후축 기준 최소 회전반경 1.15m의 원호 경로를 만들고 차량
   직사각 footprint로 정적 충돌 검사를 한다. 계획 순간 map을 동결하고 연속 유효
   위치 갱신을 확인하는 동안에는 아직 `space_found=false`를 유지한다.
5. **PARKING** — localization 확인 뒤에만 MGM 출력을 활성화한다. 원호 시작점이 앞이면 전진 접근 경로를 먼저 보낸다. 이미 지난 경우에는 scan
   lane을 직선 후진해 원호 시작점에 합류한다.
6. map-frame 경로에서 약 1m preview를 뽑아 현재 차량/GPS 자세 기준 `base_link`의
   `{x,y,yaw,curvature}` 한 점으로 변환한다. 회전 중 `|v|=0.55m/s`, 마지막
   zero-curvature 도킹 구간만 `0.15m/s`다.
7. 후방 a2 scan의 보정 거리에서 서로 가까운 5개 이상 ray가 0.20m 이하가 되면
   정지한다. 계획 끝까지 갔는데 이 조건이 없으면 자동 완료하지 않고 0속도로 멈춘다.
8. 실제 속도가 정지한 뒤 5초 대기하고, 실제 후진해 온 경로를 역순/전진으로
   재생한다. 끝에서 `done=true`, `space_found=false`를 보내 MGM이 주차 진입 전
   주행 모드(LANE 또는 WAYPOINT)로 복귀한다.

`path_blocked`는 계획 당시의 정적 벽·콘에는 쓰지 않는다. 계획 snapshot에 없던
새 점이 진행 경로 footprint를 2 frame 연속 침범할 때만 true다.

## 명령

GPS 웨이포인트 구간으로 주차 형식을 선택한다. 기존
`parking_zone_ranges`는 T자 주차, `parallel_parking_zone_ranges`는 평행
주차로 발행된다. 예:

```bash
ros2 launch adas_mgm REAL_VEHICLE_lane_gps_can.launch.py \
  REAL_VEHICLE_CONFIRM:=I_UNDERSTAND_THIS_ENABLES_REAL_CAN_TX \
  waypoint_csv:=<course.csv> parking_enabled:=true \
  t_parking_zone_ranges:="[120,140]" \
  parallel_parking_zone_ranges:="[260,285]"
```

두 구간이 겹치면 잘못된 모드를 고르지 않고 `stack_gps` 기동을 중단한다.
문자열 명령은 GPS 없는 벤치 테스트용으로 계속 사용할 수 있다.

```bash
ros2 topic pub --once /parking/gps_command std_msgs/msg/String \
  "{data: 'start perpendicular right'}"
ros2 topic pub --once /parking/gps_command std_msgs/msg/String \
  "{data: 'start parallel left'}"
```

`parking_mode=NONE`인 기존/recorded `GpsPath` 메시지는
`parking_params.yaml`의 `gps_default_mode`/`gps_default_side`를 사용해 호환한다.

GPS 없는 단독 시험은 실제 `stack_gps`를 내린 뒤에만 실행한다. 이 launch는 기존
MGM의 `gps_parking_zone && space_found` 게이트를 통과시키기 위해 test-only
`GpsPath`를 발행한다.

```bash
ros2 launch stack_parking parking_standalone.launch.py start_multi_lidar:=true
ros2 topic pub --once /parking/manual_command std_msgs/msg/String \
  "{data: 'start perpendicular right'}"
# 또는 "start parallel left", "start T자 우측", "start 1자 좌측"
ros2 topic pub --once /parking/manual_command std_msgs/msg/String "{data: cancel}"
```

단독 launch와 실제 `stack_gps`를 함께 실행하면 `/perception/gps_path` publisher가
둘이 되므로 금지한다. SCANNING 중 차량 직진은 기존 lane source를 쓰거나 bench에서
수동 이동한다.

## 실행과 토픽

```bash
# multi_lidar_fusion이 이미 실행 중
ros2 launch stack_parking parking.launch.py

# 4개 driver + fusion도 함께 시작
ros2 launch stack_parking parking.launch.py start_multi_lidar:=true

ros2 topic echo /perception/parking
ros2 topic echo /parking/diagnostics
```

입력:

- `/unified_lidar/scan` → `/parking/nearest_merged_cloud` — 4-LiDAR
  nearest-wins 통합 입력. 공용 스캔은 12m를 유지하고 주차 노드에서만
  4m로 필터링한다.
- `/lidar/a2/scan` — 후방 20cm 완료 조건.
- `/vehicle/vector` — 실제 속도 `v`와 조향 `str`로 bicycle 모델 위치를
  예측한다. `x/y/yaw`는 사용하지 않는다.
- `/perception/imu` — 선택 입력. 기본 `prior.use_imu: false`.
- `/perception/gps_path` — quality 4(RTK FIXED), `position_valid`,
  `vehicle_heading_valid`, `HEADING_FUSED`, reference age 0~0.5초인
  `position_x/y`와 `vehicle_heading_rad`를 사용한다. GPS의 ENU는 x=동쪽,
  y=북쪽, yaw=동쪽 기준 반시계방향이다. GPS 생산자는 CSV lat/lon으로
  이 좌표를 계산한다(연속 코스에서는 첫 경로의 원점을 공통으로 사용).
  CSV east_m/north_m는 기록 원점이 다를 수 있어 직접 더하지 않는다.
- `parking_map`은 초기 차량 기준 로컬 맵이다. 최초 신뢰 가능한 GPS pose와
  그때의 로컬 pose로 **고정 변환** `T_parking_enu = T_parking_body · inverse(T_enu_body)`를
  만들고, 이후 GPS 위치를 이 변환으로 옮겨 보정한다. CSV 01의 약 -135도는
  경로 진행 방향이며 실제 차량 헤딩으로 강제하지 않는다.
  GPS 품질 저하/메시지 누락 중에도 변환을 보존하며, 맵 reset 또는 GPS
  좌표계 identity 변경 시에만 다시 정렬한다. 같은 코스의 CSV 전환은 유지한다.
- 기본 위치 보정 gain은 0.15, 오차 허용 범위는 1.5m, 1회 상한은 0.2m다.
  yaw는 IMU 또는 차량 bicycle 예측을 우선하고, 둘 다 불가능하면 연속된
  신뢰 GPS 헤딩의 차이를 사용한다. TANGENT와 후진 시 모호한 COG는 거부한다.
  `/parking/diagnostics`의 `gps_map_alignment`로 실제 ENU→로컬 변환을 확인한다.

기본 `icp.map_correction_enabled: false`에서는 차량 피드백 + GPS 위치가
그대로 `/parking/slam_pose`가 된다. 라이다 점은 이 위치에 배치해 맵을 만들며,
맵 정합으로 차량 위치를 수정하지 않는다. GPS 보정이 없으면 차량 피드백으로
추정한다. GPS 보정을 받으려면 실제 `stack_gps`가 위 토픽을 발행해야 하며,
단독 시험의 합성 GPS 주차 게이트는 측위 입력으로 사용되지 않는다.

`icp.unobserved_delete_misses`를 양의 정수 N으로 설정하면 차량 기준
`icp.freespace_clear_radius_m`(4m) 이내의 점은 주변
`icp.observation_match_radius_m`(2cm)에 연속 N회 관측이 없을 때 삭제한다.
가려진 점과 빈 방향도 미관측으로 세며, 다시 관측하면 횟수를 초기화한다.
잠정/확정 점에 같은 N을 적용한다. 횟수는 새로 소비한 스캔 기준이며,
다운샘플링으로 빠진 점은 미관측으로 세지 않는다. 4m 밖의 점에는 이 삭제
규칙을 적용하지 않고, 맵 동결 단계에서는 점을 추가하거나 삭제하지 않는다.
기본값은 **5회**다. 4회까지 유지하고 5회째 미관측 시 삭제한다.
0으로 설정하면 기존의 더 먼 반사점이 확인되어야 삭제하는 방식을 사용한다.
별도 `slam_only` 뷰어는 차량/GPS 입력이 없는 라이다 ICP 시험 도구다.

출력:

- `/perception/parking` — 기존 경로/속도와 함께 10Hz 차량/GPS 측위
  `dx/dy/dyaw/update`를 전달하는 `ParkingStatus` 계약.
- `/parking/slam_pose` — 제어용 10Hz pose. `/parking/slam_scan`은 디버그 주기.
- `/parking/local_map`, `/parking/debug_markers` — mapping/space 단계.
- `/parking/reference_path`, `/parking/active_path` — map 위 경로 단계.
- `/parking/pipeline_stage` — `slam|mapping|localization|parking`.
- `/parking/diagnostics` — 위치 추정 방식(`icp_reason=vehicle_gps_prior`),
  GPS 보정 여부, 맵 상태, state/progress. 맵 정합을 끄면 ICP RMSE는 `inf`,
  match 수는 0이며 정합 실패를 뜻하지 않는다.

## RViz 4단계

```bash
rviz2 -d $(ros2 pkg prefix stack_parking)/share/stack_parking/config/parking_1_slam.rviz
rviz2 -d $(ros2 pkg prefix stack_parking)/share/stack_parking/config/parking_2_mapping.rviz
rviz2 -d $(ros2 pkg prefix stack_parking)/share/stack_parking/config/parking_3_localization.rviz
rviz2 -d $(ros2 pkg prefix stack_parking)/share/stack_parking/config/parking_4_parking.rviz
```

1. SLAM: 현재 registered scan, 누적 map, 차량/GPS vehicle pose.
2. MAPPING: endpoint map, 검출 공간, 최소반경 시작점과 최종 pose.
3. LOCALIZATION: 동결 map 위 차량/GPS 위치의 현재 scan과 계획 경로.
4. PARKING: 전체 진입 경로, 현재 gear segment, 1m preview.

기존 `parking_3_reference_path.rviz`는 호환용으로 그대로 남겨 둔다. 모든 화면의
pose text에는 현재 pipeline stage와 x/y/yaw가 함께 표시된다.

## ROS 없는 회귀 시뮬레이션

```bash
PYTHONPATH=src/stack_parking python3 -m unittest discover -s src/stack_parking/test -v
PYTHONPATH=src/stack_parking python3 -m stack_parking.simulation \
  --runs 25 --seed 20260823 --noise 0.012 --dropout 0.08
```

시뮬레이션은 평행/직각 × 좌/우, 전진 staging, 후진, 20cm 정지, 5초 대기,
역경로 출차, 동적 침범 정지/복귀, 곡률 상한과 local preview 변환을 검사한다.

## 실차 전 필수 확인

- `MEASUREMENTS.md`에 rear yaw가 아직 미검증이라고 명시되어 있다. 뒤↔좌/우 pair
  calibration 후 `lidar_mounts.yaml`을 먼저 확정한다.
- `bridge_dspace/DSPACE_LOGGING.md`에는 `/vehicle/vector` 미수신 실측 기록이 있다.
  parking 중 100Hz 회신과 counter 증가를 확인한다.
- dSPACE watchdog 미구현 기록이 있으므로 종료 시 CAN zero guard 없이는 실차를
  띄우지 않는다.
- 실제 후진 조향에서 `v=-0.55m/s`의 부호/곡률 응답과 0.15m/s 직선 도킹 제동거리를
  차륜을 띄운 bench → 저속 폐쇄 구역 순서로 검증한다.
- 후방 raw scan의 normalized 중심이 -90도인지 판을 놓고 확인한다. 5개 지지 ray와
  +0.069m 거리 바이어스는 실제 벽면 bag으로 재검증한다.
