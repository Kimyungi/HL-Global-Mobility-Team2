"""Front/rear scan synchronization and parking-local motion prediction.

This module deliberately has no ROS imports so its frame and timing contracts
can be regression-tested without hardware.  ``parking_map`` starts at the
vehicle pose used by :meth:`MotionPrior.reset`. GPS ENU poses are mapped into
that frame with a fixed SE(2) alignment; legacy motion deltas use the previous
``base_link`` frame.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
import enum
import math
from typing import Optional

import numpy as np

from .geometry import Pose2, compose, inverse, wrap_angle


@dataclass(frozen=True)
class StampedCloud:
    stamp_s: float
    receipt_s: float
    frame_id: str
    points: np.ndarray


@dataclass(frozen=True)
class CloudPair:
    front: StampedCloud
    rear: StampedCloud
    stamp_s: float
    skew_s: float

    @property
    def points(self) -> np.ndarray:
        return np.vstack((self.front.points, self.rear.points))


class FrontRearCloudPairer:
    """Consume each front/rear cloud at most once using closest timestamps."""

    def __init__(self, max_queue: int = 5):
        self.max_queue = max(2, int(max_queue))
        self._front: deque[StampedCloud] = deque()
        self._rear: deque[StampedCloud] = deque()
        self.pairs = 0
        self.stale_drops = 0
        self.sync_drops = 0

    def clear(self) -> None:
        self._front.clear()
        self._rear.clear()

    def push(self, sensor: str, cloud: StampedCloud) -> None:
        queue = self._front if sensor == 'front' else self._rear
        if sensor not in ('front', 'rear'):
            raise ValueError(f'unknown cloud sensor: {sensor}')
        queue.append(cloud)
        while len(queue) > self.max_queue:
            queue.popleft()
            self.sync_drops += 1

    def _drop_stale(self, queue: deque[StampedCloud], now_s: float,
                    stale_timeout_s: float) -> None:
        while queue and now_s - queue[0].receipt_s > stale_timeout_s:
            queue.popleft()
            self.stale_drops += 1

    def pop(self, now_s: float, sync_tolerance_s: float,
            stale_timeout_s: float) -> Optional[CloudPair]:
        self._drop_stale(self._front, now_s, stale_timeout_s)
        self._drop_stale(self._rear, now_s, stale_timeout_s)
        if not self._front or not self._rear:
            return None

        front = list(self._front)
        rear = list(self._rear)
        best_i = best_j = 0
        best_skew = math.inf
        for i, first in enumerate(front):
            for j, second in enumerate(rear):
                skew = abs(first.stamp_s - second.stamp_s)
                if skew < best_skew:
                    best_i, best_j, best_skew = i, j, skew

        if best_skew > max(0.0, sync_tolerance_s):
            # No queued pair can match.  Discard the chronologically oldest
            # endpoint so a future sample can form a pair with the newer side.
            if self._front[0].stamp_s <= self._rear[0].stamp_s:
                self._front.popleft()
            else:
                self._rear.popleft()
            self.sync_drops += 1
            return None

        for _ in range(best_i + 1):
            selected_front = self._front.popleft()
        for _ in range(best_j + 1):
            selected_rear = self._rear.popleft()
        self.sync_drops += best_i + best_j
        self.pairs += 1
        return CloudPair(
            selected_front,
            selected_rear,
            max(selected_front.stamp_s, selected_rear.stamp_s),
            best_skew,
        )


@dataclass
class MotionPriorConfig:
    velocity_timeout_s: float = 0.25
    imu_timeout_s: float = 0.25
    steering_timeout_s: float = 0.25
    max_dt_s: float = 0.30
    max_speed_mps: float = 3.0
    max_imu_rate_rad_s: float = math.radians(220.0)
    imu_jump_margin_rad: float = math.radians(3.0)
    use_imu: bool = True
    use_steering: bool = False
    wheelbase_m: float = 0.595
    steering_sign: float = -1.0
    steering_bias_rad: float = 0.0
    steering_deadband_rad: float = math.radians(0.3)
    max_steering_rad: float = math.radians(30.0)
    gps_timeout_s: float = 0.5
    gps_fix_quality: int = 4
    gps_position_gain: float = 0.15
    gps_innovation_gate_m: float = 1.50
    gps_max_correction_m: float = 0.20


@dataclass(frozen=True)
class MotionPriorStatus:
    source: str = 'uninitialized'
    velocity_fresh: bool = False
    steering_fresh: bool = False
    imu_fresh: bool = False
    steering_rad: float = 0.0
    yaw_rate_rad_s: float = 0.0
    gps_corrected: bool = False
    gps_innovation_m: float = math.inf


class MotionPrior:
    """Predict a local pose from vehicle RX, optional IMU and gated GNSS.

    GPS ENU (east, north, CCW yaw from east) is mapped into parking_map
    using a fixed SE(2) transform anchored at the first trusted GPS pose.
    GPS position never uses a waypoint tangent as vehicle heading. Legacy
    body-delta callers are retained through update_gps. Yaw prediction prefers
    direct IMU or vehicle steering; GPS heading differences are a fallback.
    """

    def __init__(self, config: Optional[MotionPriorConfig] = None):
        self.config = config or MotionPriorConfig()
        self.reset()

    def reset(self, pose: Pose2 = Pose2()) -> None:
        self.pose = pose
        self._last_predict_s: Optional[float] = None
        self._velocity_mps = 0.0
        self._velocity_stamp_s = -math.inf
        self._steering_rad = 0.0
        self._steering_stamp_s = -math.inf
        self._imu_yaw_rad: Optional[float] = None
        self._imu_stamp_s = -math.inf
        self._last_used_imu_yaw: Optional[float] = None
        self._gps_pose: Optional[Pose2] = None
        self._last_gps_update: Optional[int] = None
        self._pending_gps_yaw = 0.0
        self._gps_position_pending = False
        self.gps_map_transform: Optional[Pose2] = None  # parking_map <- GPS ENU
        self._gps_frame_key = None
        self._gps_absolute_stamp_s = -math.inf
        self._gps_absolute_previous: Optional[Pose2] = None
        self.last_status = MotionPriorStatus()

    def update_velocity(self, velocity_mps: float, stamp_s: float) -> None:
        if not math.isfinite(velocity_mps) or not math.isfinite(stamp_s):
            return
        limit = max(0.0, self.config.max_speed_mps)
        self._velocity_mps = max(-limit, min(limit, float(velocity_mps)))
        self._velocity_stamp_s = float(stamp_s)

    def update_steering(self, steering_rad: float, stamp_s: float) -> None:
        if not math.isfinite(steering_rad) or not math.isfinite(stamp_s):
            return
        limit = max(0.0, self.config.max_steering_rad)
        self._steering_rad = max(-limit, min(limit, float(steering_rad)))
        self._steering_stamp_s = float(stamp_s)

    def update_vehicle(self, velocity_mps: float, steering_rad: float,
                       stamp_s: float) -> None:
        """Consume the two trusted dSPACE RX fields from one sample."""
        self.update_velocity(velocity_mps, stamp_s)
        self.update_steering(steering_rad, stamp_s)

    def update_imu(self, yaw_rad: float, stamp_s: float) -> None:
        if not math.isfinite(yaw_rad) or not math.isfinite(stamp_s):
            return
        self._imu_yaw_rad = float(yaw_rad)
        self._imu_stamp_s = float(stamp_s)

    def invalidate_gps(self) -> None:
        """Drop pending data, preserving the absolute ENU alignment across gaps.

        Legacy deltas need a new baseline; absolute positions do not lose their
        frame just because a fix or heading was temporarily unavailable.
        """
        self._gps_pose = None
        self._last_gps_update = None
        self._pending_gps_yaw = 0.0
        self._gps_position_pending = False
        self._gps_absolute_previous = None

    def update_gps_pose(
        self, update: int, enu_pose: Pose2, stamp_s: float, now_s: float,
        fix_quality: int, heading_reliable: bool, *, frame_key=None,
        use_yaw_fallback: bool = True,
    ) -> bool:
        """Accept an absolute GPS pose in the waypoint producer's ENU frame.

        p_parking = R(yaw_parking0 - yaw_gps0) p_enu + translation.
        The transform stays fixed through turns, missing counters and RTK
        outages. A new GPS coordinate frame or explicit map reset re-anchors.
        """
        if (int(fix_quality) != int(self.config.gps_fix_quality)
                or not heading_reliable
                or not all(math.isfinite(v) for v in
                           (enu_pose.x, enu_pose.y, enu_pose.yaw, stamp_s, now_s))
                or stamp_s <= 0.0
                or not 0.0 <= now_s - stamp_s <= self.config.gps_timeout_s):
            self.invalidate_gps()
            return False
        if stamp_s <= self._gps_absolute_stamp_s:
            return False  # duplicate publication or out-of-order fix
        previous_stamp = self._gps_absolute_stamp_s
        self._gps_absolute_stamp_s = float(stamp_s)
        if self.gps_map_transform is None or frame_key != self._gps_frame_key:
            self.invalidate_gps()
            self.gps_map_transform = compose(self.pose, inverse(enu_pose))
            self._gps_frame_key = frame_key
            self._gps_pose = self.pose
        else:
            self._gps_pose = compose(self.gps_map_transform, enu_pose)
            self._gps_position_pending = True
        if (use_yaw_fallback and self._gps_absolute_previous is not None
                and stamp_s - previous_stamp <= self.config.gps_timeout_s):
            self._pending_gps_yaw = wrap_angle(
                self._pending_gps_yaw
                + wrap_angle(enu_pose.yaw - self._gps_absolute_previous.yaw))
        self._gps_absolute_previous = enu_pose
        self._last_gps_update = int(update)
        return True

    def update_gps(
        self,
        update: int,
        dx: float,
        dy: float,
        dyaw: float,
        fix_quality: int,
        heading_reliable: bool,
    ) -> bool:
        """Consume one new RTK delta; return whether it was accepted."""
        counter = int(update)
        if int(fix_quality) != int(self.config.gps_fix_quality):
            self.invalidate_gps()
            return False
        if not all(math.isfinite(value) for value in (dx, dy, dyaw)):
            self.invalidate_gps()
            return False
        if self._last_gps_update == counter:
            return False

        if (self._last_gps_update is not None
                and counter != (self._last_gps_update + 1) % (1 << 64)):
            self.invalidate_gps()
        self._last_gps_update = counter
        if self._gps_pose is None:
            # The first post-reset sample establishes the same local origin;
            # its delta may predate reset and must not be replayed.
            self._gps_pose = self.pose
            return True

        delta = Pose2(float(dx), float(dy), wrap_angle(float(dyaw)))
        self._gps_pose = compose(self._gps_pose, delta)
        self._gps_position_pending = True
        if heading_reliable:
            self._pending_gps_yaw = wrap_angle(
                self._pending_gps_yaw + delta.yaw)
        return True

    @staticmethod
    def _fresh(sample_s: float, target_s: float, timeout_s: float) -> bool:
        # Independent 10 Hz sensor timers can be almost one full phase apart.
        # The newest sample on either side of the paired scan is accepted only
        # inside the configured bound; larger clock jumps remain invalid.
        return abs(target_s - sample_s) <= max(0.0, timeout_s)

    @staticmethod
    def _integrate_body_motion(pose: Pose2, distance_m: float,
                               yaw_delta: float) -> Pose2:
        if abs(yaw_delta) < 1.0e-7:
            dx_body, dy_body = distance_m, 0.0
        else:
            radius = distance_m / yaw_delta
            dx_body = radius * math.sin(yaw_delta)
            dy_body = radius * (1.0 - math.cos(yaw_delta))
        c, s = math.cos(pose.yaw), math.sin(pose.yaw)
        return Pose2(
            pose.x + c * dx_body - s * dy_body,
            pose.y + s * dx_body + c * dy_body,
            wrap_angle(pose.yaw + yaw_delta),
        )

    def predict(self, stamp_s: float) -> Pose2:
        stamp_s = float(stamp_s)
        if (self.gps_map_transform is not None
                and stamp_s - self._gps_absolute_stamp_s > self.config.gps_timeout_s):
            self.invalidate_gps()
        imu_fresh = (
            self.config.use_imu
            and
            self._imu_yaw_rad is not None
            and self._fresh(self._imu_stamp_s, stamp_s,
                            self.config.imu_timeout_s)
        )
        velocity_fresh = self._fresh(
            self._velocity_stamp_s, stamp_s, self.config.velocity_timeout_s)
        steering_fresh = (
            self.config.use_steering
            and self._fresh(self._steering_stamp_s, stamp_s,
                            self.config.steering_timeout_s)
        )

        if self._last_predict_s is None:
            self._last_predict_s = stamp_s
            self._last_used_imu_yaw = self._imu_yaw_rad if imu_fresh else None
            self.last_status = MotionPriorStatus(
                source='baseline', velocity_fresh=velocity_fresh,
                steering_fresh=steering_fresh, imu_fresh=imu_fresh)
            return self.pose

        dt = stamp_s - self._last_predict_s
        self._last_predict_s = stamp_s
        if dt <= 0.0 or dt > self.config.max_dt_s:
            self._last_used_imu_yaw = self._imu_yaw_rad if imu_fresh else None
            self._pending_gps_yaw = 0.0
            self.last_status = MotionPriorStatus(
                source='time_reset', velocity_fresh=velocity_fresh,
                steering_fresh=steering_fresh, imu_fresh=imu_fresh)
            return self.pose

        yaw_delta = 0.0
        yaw_rate = 0.0
        steering_ros = 0.0
        source = 'yaw_held'
        if imu_fresh:
            source = 'imu'
            if self._last_used_imu_yaw is not None:
                candidate = wrap_angle(
                    self._imu_yaw_rad - self._last_used_imu_yaw)
                maximum = (
                    max(0.0, self.config.max_imu_rate_rad_s) * dt
                    + max(0.0, self.config.imu_jump_margin_rad)
                )
                if abs(candidate) <= maximum:
                    yaw_delta = candidate
                else:
                    source = 'imu_jump_rejected'
            self._last_used_imu_yaw = self._imu_yaw_rad
            # Never replay GPS yaw accumulated while direct IMU was healthy.
            self._pending_gps_yaw = 0.0
        elif velocity_fresh and steering_fresh:
            steering_ros = self.config.steering_sign * (
                self._steering_rad - self.config.steering_bias_rad)
            if abs(steering_ros) <= max(0.0, self.config.steering_deadband_rad):
                steering_ros = 0.0
            limit = min(max(0.0, self.config.max_steering_rad),
                        math.radians(89.0))
            steering_ros = max(-limit, min(limit, steering_ros))
            wheelbase = max(1.0e-3, self.config.wheelbase_m)
            yaw_rate = self._velocity_mps * math.tan(steering_ros) / wheelbase
            yaw_delta = yaw_rate * dt
            source = 'vehicle_bicycle'
            self._last_used_imu_yaw = None
            self._pending_gps_yaw = 0.0
        else:
            self._last_used_imu_yaw = None
            if velocity_fresh:
                source = 'velocity_only'
            if abs(self._pending_gps_yaw) > 0.0:
                yaw_delta = self._pending_gps_yaw
                self._pending_gps_yaw = 0.0
                source = 'gps_dyaw_fallback'

        distance = self._velocity_mps * dt if velocity_fresh else 0.0
        self.pose = self._integrate_body_motion(self.pose, distance, yaw_delta)

        corrected = False
        innovation_m = math.inf
        if self._gps_position_pending and self._gps_pose is not None:
            error_x = self._gps_pose.x - self.pose.x
            error_y = self._gps_pose.y - self.pose.y
            innovation_m = math.hypot(error_x, error_y)
            if innovation_m <= max(0.0, self.config.gps_innovation_gate_m):
                gain = min(max(self.config.gps_position_gain, 0.0), 1.0)
                step_x, step_y = gain * error_x, gain * error_y
                step_m = math.hypot(step_x, step_y)
                limit = max(0.0, self.config.gps_max_correction_m)
                if limit > 0.0 and step_m > limit:
                    scale = limit / step_m
                    step_x, step_y = step_x * scale, step_y * scale
                self.pose = Pose2(
                    self.pose.x + step_x,
                    self.pose.y + step_y,
                    self.pose.yaw,
                )
                corrected = gain > 0.0
            self._gps_position_pending = False

        self.last_status = MotionPriorStatus(
            source=source,
            velocity_fresh=velocity_fresh,
            steering_fresh=steering_fresh,
            imu_fresh=imu_fresh,
            steering_rad=steering_ros,
            yaw_rate_rad_s=yaw_rate,
            gps_corrected=corrected,
            gps_innovation_m=innovation_m,
        )
        return self.pose


class PipelineStage(str, enum.Enum):
    SLAM = 'slam'
    MAPPING = 'mapping'
    LOCALIZATION = 'localization'
    PARKING = 'parking'


class PipelineController:
    """Own the four parking perception stages independently of mission detail."""

    def __init__(self, slam_confirm_scans: int = 10,
                 localization_confirm_scans: int = 3,
                 minimum_map_points: int = 80):
        self.slam_confirm_scans = max(1, int(slam_confirm_scans))
        self.localization_confirm_scans = max(
            1, int(localization_confirm_scans))
        self.minimum_map_points = max(1, int(minimum_map_points))
        self.reset()

    def reset(self) -> None:
        self.stage = PipelineStage.SLAM
        self.slam_accepted = 0
        self.localization_accepted = 0

    @property
    def mapping_enabled(self) -> bool:
        return self.stage in (PipelineStage.SLAM, PipelineStage.MAPPING)

    @property
    def parking_enabled(self) -> bool:
        return self.stage == PipelineStage.PARKING

    def observe_slam(self, accepted: bool, map_points: int) -> bool:
        """Update confirmation counts; return True when the stage changes."""
        previous = self.stage
        if self.stage == PipelineStage.SLAM:
            self.slam_accepted = self.slam_accepted + 1 if accepted else 0
            if (
                self.slam_accepted >= self.slam_confirm_scans
                and int(map_points) >= self.minimum_map_points
            ):
                self.stage = PipelineStage.MAPPING
        elif self.stage == PipelineStage.LOCALIZATION:
            self.localization_accepted = (
                self.localization_accepted + 1 if accepted else 0)
            if self.localization_accepted >= self.localization_confirm_scans:
                self.stage = PipelineStage.PARKING
        return self.stage != previous

    def plan_ready(self) -> bool:
        if self.stage != PipelineStage.MAPPING:
            return False
        self.stage = PipelineStage.LOCALIZATION
        self.localization_accepted = 0
        return True

    def return_to_mapping(self, map_initialized: bool) -> None:
        self.stage = (
            PipelineStage.MAPPING if map_initialized else PipelineStage.SLAM)
        self.localization_accepted = 0
