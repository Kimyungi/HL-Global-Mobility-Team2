"""Vehicle/GPS localization and LiDAR mapping parking pipeline ROS 2 wrapper.

Decision ownership remains in ``adas_mgm``. Until a stable, feasible parking
space exists this node publishes ``space_found=False`` and the existing lane or
GPS stack keeps the car moving straight. Once a plan exists, this node emits
one current-vehicle-frame preview point, matching ``ParkingStatus.msg``.
"""

from __future__ import annotations

from collections import deque
import math
from typing import Optional

import numpy as np

import rclpy
from rclpy.node import Node
from rclpy.time import Time
from rclpy.qos import qos_profile_sensor_data

from diagnostic_msgs.msg import DiagnosticArray, DiagnosticStatus, KeyValue
from fma_interfaces.msg import GpsPath, ParkingStatus, RefPoint, VehicleVector
from geometry_msgs.msg import Point, PoseStamped
from nav_msgs.msg import Path
from sensor_msgs.msg import Imu, LaserScan, PointCloud2
from sensor_msgs_py import point_cloud2
from std_msgs.msg import Header, String
from visualization_msgs.msg import Marker, MarkerArray

from fma_interfaces.msg import ParkingCommand, ParkingWallStatus

from .geometry import Pose2, transform_points
from .icp_slam import IcpConfig, IcpSlam, voxel_downsample
from .localization import (
    FrontRearCloudPairer,
    MotionPrior,
    MotionPriorConfig,
    PipelineController,
    PipelineStage,
    StampedCloud,
)
from .mission import MissionConfig, MissionOutput, MissionState, ParkingMission
from .path_planner import MinimumRadiusParkingPlanner, PlannerConfig
from .space_detector import (
    MODE_PARALLEL,
    MODE_PERPENDICULAR,
    SIDE_AUTO,
    SIDE_LEFT,
    SIDE_RIGHT,
    ParkingSpaceDetector,
    SpaceDetectorConfig,
)
from .wall_gap_controller import PoseDeltaTracker


def _quaternion_z(yaw: float) -> tuple[float, float]:
    return math.sin(0.5 * yaw), math.cos(0.5 * yaw)


def _angle_distance(a: float, b: float) -> float:
    return (a - b + math.pi) % (2.0 * math.pi) - math.pi


class StackParkingNode(Node):

    def __init__(self):
        super().__init__('stack_parking_node')
        self._declare_parameters()
        self.map_frame = str(self.get_parameter('map_frame').value)
        self.base_frame = str(self.get_parameter('base_frame').value)

        self.slam = IcpSlam(self._icp_config())
        self.prior = MotionPrior(self._motion_prior_config())
        self.pipeline = PipelineController(
            slam_confirm_scans=int(self._p('stage.slam_confirm_scans')),
            localization_confirm_scans=int(
                self._p('stage.localization_confirm_scans')),
            minimum_map_points=int(self._p('stage.minimum_map_points')),
        )
        self.cloud_pairer = FrontRearCloudPairer(
            int(self._p('cloud.queue_size')))
        detector = ParkingSpaceDetector(self._detector_config())
        planner = MinimumRadiusParkingPlanner(self._planner_config())
        self.mission = ParkingMission(detector, planner, self._mission_config())
        self.pose_delta_tracker = PoseDeltaTracker()
        self.search_request_id = 0
        self.search_mission_mode = 0
        self.search_running = False
        self.execution_authorized = False
        self.search_start_s = -math.inf
        self.latest_wall_status = None
        self.left_wall_sub = self.create_subscription(
            ParkingWallStatus, '/parking/left_wall/status', self._on_wall_status, 1)

        self.latest_vehicle: Optional[VehicleVector] = None
        self.latest_rear_clearance_m: Optional[float] = None
        self.latest_rear_scan_s = -math.inf
        self.last_icp_result = None
        self.last_icp_accepted_s = -math.inf
        self.last_debug_publish_s = -math.inf
        self.latest_scan_map = np.empty((0, 2), dtype=np.float64)
        self.gps_zone_armed = True
        self.manual_gate_active = False
        self.last_output: Optional[MissionOutput] = None
        self.latest_front_cloud_s = -math.inf
        self.latest_rear_cloud_s = -math.inf
        self.latest_merged_cloud: Optional[StampedCloud] = None
        self.latest_imu_s = -math.inf
        self.latest_vehicle_s = -math.inf
        self.last_pair_skew_s = math.inf
        self.last_slam_update_s = -math.inf
        self.reference_input_stamp_s = -math.inf
        self.slam_update_times: deque[float] = deque(maxlen=30)
        self._last_frame_warning_s = -math.inf

        self.status_pub = self.create_publisher(
            ParkingStatus, '/perception/parking', 1)
        self.pose_pub = self.create_publisher(
            PoseStamped, '/parking/slam_pose', 1)
        self.pose_text_pub = self.create_publisher(
            Marker, '/parking/slam_pose_text', 1)
        self.scan_pub = self.create_publisher(
            PointCloud2, '/parking/slam_scan', 1)
        self.map_pub = self.create_publisher(
            PointCloud2, '/parking/local_map', 1)
        self.path_pub = self.create_publisher(
            Path, '/parking/reference_path', 1)
        self.active_path_pub = self.create_publisher(
            Path, '/parking/active_path', 1)
        self.marker_pub = self.create_publisher(
            MarkerArray, '/parking/debug_markers', 1)
        self.diagnostic_pub = self.create_publisher(
            DiagnosticArray, '/parking/diagnostics', 1)
        self.stage_pub = self.create_publisher(
            String, '/parking/pipeline_stage', 1)
        self.manual_gate_pub = None
        if bool(self.get_parameter('manual_test_publish_gps_gate').value):
            self.manual_gate_pub = self.create_publisher(
                GpsPath, '/perception/gps_path', 1)

        # merged_cloud_topic (empty by default): when set, this single
        # already-unified 4-sensor cloud (overlap resolved upstream, e.g.
        # lidar_fusion_v2's nearest-per-bin /unified_lidar/scan) replaces the
        # front/rear pairer entirely — front_cloud_topic/rear_cloud_topic are
        # not subscribed in that mode. See §CLAUDE.md Parking pipeline note:
        # front/rear-only was chosen because side RPLiDARs (b1/b2) kept
        # dropping USB power; merged mode assumes that is now resolved.
        merged_topic = str(self._p('merged_cloud_topic'))
        self._merged_mode = bool(merged_topic)
        front_topic = str(self.get_parameter('front_cloud_topic').value)
        rear_cloud_topic = str(self.get_parameter('rear_cloud_topic').value)
        rear_topic = str(self.get_parameter('rear_scan_topic').value)
        self.merged_cloud_sub = None
        self.front_cloud_sub = None
        self.rear_cloud_sub = None
        if self._merged_mode:
            self.merged_cloud_sub = self.create_subscription(
                PointCloud2, merged_topic, self._on_merged_cloud,
                qos_profile_sensor_data)
        else:
            self.front_cloud_sub = self.create_subscription(
                PointCloud2, front_topic, self._on_front_cloud,
                qos_profile_sensor_data)
            self.rear_cloud_sub = self.create_subscription(
                PointCloud2, rear_cloud_topic, self._on_rear_cloud,
                qos_profile_sensor_data)
        self.rear_sub = self.create_subscription(
            LaserScan, rear_topic, self._on_rear_scan, qos_profile_sensor_data)
        self.vehicle_sub = self.create_subscription(
            VehicleVector, str(self._p('vehicle_topic')), self._on_vehicle,
            qos_profile_sensor_data)
        self.imu_sub = None
        if bool(self._p('prior.use_imu')):
            self.imu_sub = self.create_subscription(
                Imu, str(self._p('imu_topic')), self._on_imu,
                qos_profile_sensor_data)
        self.gps_sub = self.create_subscription(
            GpsPath, str(self._p('gps_topic')), self._on_gps_path, 1)
        self.mission_command_sub = self.create_subscription(
            ParkingCommand, '/parking/mission_command', self._on_mission_command, 10)
        self.gps_command_sub = self.create_subscription(
            String, '/parking/gps_command', self._on_command, 10)
        self.manual_command_sub = self.create_subscription(
            String, '/parking/manual_command', self._on_command, 10)

        publish_rate = float(self.get_parameter('publish_rate_hz').value)
        self.timer = self.create_timer(1.0 / max(1.0, publish_rate), self._tick)
        slam_rate = float(self._p('slam_rate_hz'))
        self.slam_timer = self.create_timer(
            1.0 / max(1.0, slam_rate), self._process_slam)
        if self._merged_mode:
            self.get_logger().info(
                'merged-cloud parking ready: merged=%s rear_scan=%s '
                'slam=%.1fHz stage=%s manual=/parking/manual_command '
                '(start perpendicular right | start parallel right | cancel)'
                % (merged_topic, rear_topic, slam_rate, self.pipeline.stage.value))
        else:
            self.get_logger().info(
                'front/rear parking ready: front=%s rear_cloud=%s rear_scan=%s '
                'slam=%.1fHz stage=%s manual=/parking/manual_command '
                '(start perpendicular right | start parallel right | cancel)'
                % (front_topic, rear_cloud_topic, rear_topic, slam_rate,
                   self.pipeline.stage.value))

    def _declare_parameters(self) -> None:
        values = {
            'map_frame': 'parking_map',
            'base_frame': 'base_link',
            'front_cloud_topic': '/lidar/a1/cloud',
            'rear_cloud_topic': '/lidar/a2/cloud',
            # Non-empty switches to single-source merged-cloud mode (see
            # __init__) instead of the front/rear pairer.
            'merged_cloud_topic': '',
            'rear_scan_topic': '/lidar/a2/scan',
            'vehicle_topic': '/vehicle/vector',
            'imu_topic': '/perception/imu',
            'gps_topic': '/perception/gps_path',
            'slam_rate_hz': 10.0,
            'publish_rate_hz': 10.0,
            'debug_publish_rate_hz': 5.0,
            'cloud.sync_tolerance_s': 0.08,
            'cloud.stale_timeout_s': 0.35,
            'cloud.queue_size': 5,
            'cloud.min_range_m': 0.15,
            # Parking-only cutoff; never shorten the shared fused scan.
            'cloud.max_range_m': 4.0,
            'cloud.self_filter_margin_m': 0.02,
            'prior.velocity_timeout_s': 0.25,
            'prior.imu_timeout_s': 0.25,
            'prior.steering_timeout_s': 0.25,
            'prior.max_dt_s': 0.30,
            'prior.max_speed_mps': 3.0,
            'prior.max_imu_rate_deg_s': 220.0,
            'prior.imu_jump_margin_deg': 3.0,
            'prior.use_imu': False,
            'prior.use_steering': True,
            'prior.steering_sign': -1.0,
            'prior.steering_bias_deg': 0.0,
            'prior.steering_deadband_deg': 0.3,
            'prior.max_steering_deg': 30.0,
            'gps.use_position_correction': True,
            'gps.use_yaw_fallback': True,
            'gps.timeout_s': 0.5,
            'gps.fix_quality': 4,
            'gps.position_gain': 0.15,
            'gps.innovation_gate_m': 1.50,
            'gps.max_correction_m': 0.20,
            'stage.slam_confirm_scans': 10,
            'stage.localization_confirm_scans': 3,
            'stage.minimum_map_points': 80,
            # 2026-09-02 (user directive): parking mode starts a fresh map,
            # it does not park against whatever the vehicle happened to map
            # beforehand.
            'reset_map_on_mission_start': True,
            'auto_trigger_gps_zone': False,  # MGM owns mission start; legacy zone mode is explicit
            'gps_default_mode': MODE_PERPENDICULAR,
            'gps_default_side': SIDE_AUTO,
            # Test-only: synthesizes the existing MGM GPS gate after a manual
            # command. Never enable while the real stack_gps publisher runs.
            'manual_test_publish_gps_gate': False,
            'slam_stale_timeout_s': 0.6,
            'rear_scan_stale_timeout_s': 0.35,
            'rear_scan_center_deg': -90.0,
            'rear_scan_half_width_deg': 12.0,
            'rear_range_offset_m': 0.069,
            'rear_wall_min_points': 5,
            'rear_wall_cluster_m': 0.04,
            # Vehicle values mirror stack_avoid/config/params.yaml, the project
            # single source documented in stack_parking/MEASUREMENTS.md.
            'vehicle.width_m': 0.62,
            'vehicle.length_m': 0.85,
            'vehicle.front_m': 0.760,
            'vehicle.rear_m': 0.090,
            'vehicle.wheelbase_m': 0.595,
            'vehicle.min_turn_radius_m': 1.15,
            'lidar.rear_x_m': -0.110354,
            'icp.map_correction_enabled': False,
            'icp.unobserved_delete_misses': 5,
            'icp.scan_voxel_m': 0.06,
            'icp.max_scan_points': 900,
            # Keep the fallback consistent with parking_params.yaml.  Eight
            # centimetres preserves the parking-map detail needed around
            # curbs and cones; calibration residuals should be fixed at the
            # sensor extrinsics rather than hidden with a coarser map voxel.
            'icp.map_voxel_m': 0.08,
            'icp.max_correspondence_m': 0.35,
            'icp.max_iterations': 18,
            'icp.min_correspondences': 24,
            'icp.max_rmse_m': 0.16,
            'icp.local_map_radius_m': 8.0,
            # Below this matched-point angular span, ICP's yaw correction is
            # discarded (kept at the odometry prior) — narrow-aperture views
            # (e.g. one wall while turning) under-constrain rotation and can
            # converge to a wrong-but-low-RMSE heading, duplicating that wall
            # in the map at each mis-rotated pose.
            'icp.min_yaw_observable_span_deg': 50.0,
            'icp.freespace_clear_enabled': True,
            # Match the parking-only cloud cutoff above. The public fused
            # scan intentionally remains 12 m for other safety consumers.
            'icp.freespace_clear_radius_m': 4.0,
            'icp.freespace_bin_width_deg': 1.0,
            'icp.freespace_margin_m': 0.02,
            'icp.freespace_occlusion_padding_deg': 1.5,
            'icp.observation_match_radius_m': 0.02,
            'icp.tentative_confirm_hits': 3,
            'icp.tentative_delete_misses': 1,
            'icp.confirmed_delete_misses': 3,
            # 2026-09-02: 0.42/1.05 -> 1.7/2.3, tuned to this test rig by
            # replaying the live map (see space_detector.py _mouth_clusters
            # docstring for why plain x-clustering couldn't see this bay at
            # all). This room has other objects sitting at side_distance up
            # to ~1.65m that aren't the bay; the bay's own arms start at
            # ~1.7m and its back wall sits at ~2.7m. The field side-wall
            # search now extends to 3m; perpendicular back-wall depth is
            # classified independently by perpendicular_min_depth_m.
            'space.boundary_near_m': 1.7,
            'space.boundary_far_m': 3.0,
            'space.parallel_min_length_m': 2.90,
            'space.parallel_decision_wall_min_length_m': 0.08,
            'space.parallel_decision_wall_min_points': 1,
            'space.parallel_decision_wall_x_tolerance_m': 0.10,
            'space.parallel_corner_connect_tolerance_m': 0.14,
            'space.parallel_corner_max_angle_error_deg': 35.0,
            'space.parallel_side_wall_min_length_m': 0.50,
            # 2026-09-02 (user directive): 1m x 1m minimum, first gap wins.
            'space.perpendicular_min_width_m': 1.0,
            'space.perpendicular_min_depth_m': 1.0,
            'space.stable_frames': 3,
            'path.sample_step_m': 0.06,
            'path.static_clearance_m': 0.035,
            'preview_distance_m': 1.0,
            'speed.forward_mps': 0.60,
            'speed.reverse_turn_mps': 0.55,
            'speed.reverse_dock_mps': 0.15,
            'speed.exit_mps': 0.55,
            'dock_slow_distance_m': 0.55,
            'completion_clearance_m': 0.20,
            'completion_trigger_margin_m': 0.02,
            'parked_wait_s': 5.0,
            'require_vehicle_stop_feedback': True,
            'dynamic.confirm_frames': 2,
            'dynamic.static_match_m': 0.14,
            'dynamic.clearance_m': 0.12,
        }
        for name, value in values.items():
            self.declare_parameter(name, value)

    def _p(self, name: str):
        return self.get_parameter(name).value

    def _icp_config(self) -> IcpConfig:
        return IcpConfig(
            map_correction_enabled=bool(self._p('icp.map_correction_enabled')),
            unobserved_delete_misses=int(self._p('icp.unobserved_delete_misses')),
            scan_voxel_m=float(self._p('icp.scan_voxel_m')),
            max_scan_points=int(self._p('icp.max_scan_points')),
            map_voxel_m=float(self._p('icp.map_voxel_m')),
            max_correspondence_m=float(self._p('icp.max_correspondence_m')),
            max_iterations=int(self._p('icp.max_iterations')),
            min_correspondences=int(self._p('icp.min_correspondences')),
            max_rmse_m=float(self._p('icp.max_rmse_m')),
            local_map_radius_m=float(self._p('icp.local_map_radius_m')),
            min_yaw_observable_span_rad=math.radians(
                float(self._p('icp.min_yaw_observable_span_deg'))),
            freespace_clear_enabled=bool(self._p('icp.freespace_clear_enabled')),
            freespace_clear_radius_m=float(self._p('icp.freespace_clear_radius_m')),
            freespace_bin_width_rad=math.radians(
                float(self._p('icp.freespace_bin_width_deg'))),
            freespace_margin_m=float(self._p('icp.freespace_margin_m')),
            freespace_occlusion_padding_rad=math.radians(
                float(self._p('icp.freespace_occlusion_padding_deg'))),
            observation_match_radius_m=float(
                self._p('icp.observation_match_radius_m')),
            tentative_confirm_hits=int(self._p('icp.tentative_confirm_hits')),
            tentative_delete_misses=int(self._p('icp.tentative_delete_misses')),
            confirmed_delete_misses=int(self._p('icp.confirmed_delete_misses')),
        )

    def _motion_prior_config(self) -> MotionPriorConfig:
        return MotionPriorConfig(
            velocity_timeout_s=float(self._p('prior.velocity_timeout_s')),
            imu_timeout_s=float(self._p('prior.imu_timeout_s')),
            steering_timeout_s=float(self._p('prior.steering_timeout_s')),
            max_dt_s=float(self._p('prior.max_dt_s')),
            max_speed_mps=float(self._p('prior.max_speed_mps')),
            max_imu_rate_rad_s=math.radians(
                float(self._p('prior.max_imu_rate_deg_s'))),
            imu_jump_margin_rad=math.radians(
                float(self._p('prior.imu_jump_margin_deg'))),
            use_imu=bool(self._p('prior.use_imu')),
            use_steering=bool(self._p('prior.use_steering')),
            wheelbase_m=float(self._p('vehicle.wheelbase_m')),
            steering_sign=float(self._p('prior.steering_sign')),
            steering_bias_rad=math.radians(
                float(self._p('prior.steering_bias_deg'))),
            steering_deadband_rad=math.radians(
                float(self._p('prior.steering_deadband_deg'))),
            max_steering_rad=math.radians(
                float(self._p('prior.max_steering_deg'))),
            gps_timeout_s=float(self._p('gps.timeout_s')),
            gps_fix_quality=int(self._p('gps.fix_quality')),
            gps_position_gain=(
                float(self._p('gps.position_gain'))
                if bool(self._p('gps.use_position_correction')) else 0.0),
            gps_innovation_gate_m=float(self._p('gps.innovation_gate_m')),
            gps_max_correction_m=float(self._p('gps.max_correction_m')),
        )

    def _detector_config(self) -> SpaceDetectorConfig:
        return SpaceDetectorConfig(
            vehicle_width_m=float(self._p('vehicle.width_m')),
            vehicle_length_m=float(self._p('vehicle.length_m')),
            boundary_near_m=float(self._p('space.boundary_near_m')),
            boundary_far_m=float(self._p('space.boundary_far_m')),
            parallel_min_length_m=float(self._p('space.parallel_min_length_m')),
            parallel_decision_wall_min_length_m=float(
                self._p('space.parallel_decision_wall_min_length_m')),
            parallel_decision_wall_min_points=int(
                self._p('space.parallel_decision_wall_min_points')),
            parallel_decision_wall_x_tolerance_m=float(
                self._p('space.parallel_decision_wall_x_tolerance_m')),
            parallel_corner_connect_tolerance_m=float(
                self._p('space.parallel_corner_connect_tolerance_m')),
            parallel_corner_max_angle_error_deg=float(
                self._p('space.parallel_corner_max_angle_error_deg')),
            parallel_side_wall_min_length_m=float(
                self._p('space.parallel_side_wall_min_length_m')),
            perpendicular_min_width_m=float(self._p('space.perpendicular_min_width_m')),
            perpendicular_min_depth_m=float(self._p('space.perpendicular_min_depth_m')),
            rear_lidar_x_m=float(self._p('lidar.rear_x_m')),
            completion_clearance_m=float(self._p('completion_clearance_m')),
            completion_trigger_margin_m=float(self._p('completion_trigger_margin_m')),
            stable_frames=int(self._p('space.stable_frames')),
        )

    def _planner_config(self) -> PlannerConfig:
        return PlannerConfig(
            min_turn_radius_m=float(self._p('vehicle.min_turn_radius_m')),
            sample_step_m=float(self._p('path.sample_step_m')),
            vehicle_width_m=float(self._p('vehicle.width_m')),
            vehicle_front_m=float(self._p('vehicle.front_m')),
            vehicle_rear_m=float(self._p('vehicle.rear_m')),
            static_clearance_m=float(self._p('path.static_clearance_m')),
        )

    def _mission_config(self) -> MissionConfig:
        return MissionConfig(
            preview_distance_m=float(self._p('preview_distance_m')),
            forward_speed_mps=float(self._p('speed.forward_mps')),
            reverse_turn_speed_mps=float(self._p('speed.reverse_turn_mps')),
            reverse_dock_speed_mps=float(self._p('speed.reverse_dock_mps')),
            exit_speed_mps=float(self._p('speed.exit_mps')),
            dock_slow_distance_m=float(self._p('dock_slow_distance_m')),
            completion_clearance_m=float(self._p('completion_clearance_m')),
            parked_wait_s=float(self._p('parked_wait_s')),
            require_stationary_feedback=bool(self._p('require_vehicle_stop_feedback')),
            dynamic_confirm_frames=int(self._p('dynamic.confirm_frames')),
            dynamic_static_match_m=float(self._p('dynamic.static_match_m')),
            dynamic_clearance_m=float(self._p('dynamic.clearance_m')),
        )

    def _clock_s(self) -> float:
        return self.get_clock().now().nanoseconds * 1.0e-9

    @staticmethod
    def _message_stamp_s(stamp, fallback_s: float) -> float:
        value = float(stamp.sec) + float(stamp.nanosec) * 1.0e-9
        return value if value > 0.0 else fallback_s

    def _on_vehicle(self, msg: VehicleVector) -> None:
        self.latest_vehicle = msg
        now_s = self._clock_s()
        self.latest_vehicle_s = now_s
        self.prior.update_vehicle(
            float(msg.v), float(msg.str),
            self._message_stamp_s(msg.header.stamp, now_s))

    def _on_imu(self, msg: Imu) -> None:
        q = msg.orientation
        norm = math.sqrt(
            q.x * q.x + q.y * q.y + q.z * q.z + q.w * q.w)
        if norm < 1.0e-6:
            return
        # General quaternion-to-yaw conversion; stack_gps currently publishes
        # a yaw-only quaternion but this remains correct for a future 3-D IMU.
        sin_yaw = 2.0 * (q.w * q.z + q.x * q.y) / (norm * norm)
        cos_yaw = (
            1.0 - 2.0 * (q.y * q.y + q.z * q.z) / (norm * norm))
        now_s = self._clock_s()
        stamp_s = self._message_stamp_s(msg.header.stamp, now_s)
        self.prior.update_imu(math.atan2(sin_yaw, cos_yaw), stamp_s)
        self.latest_imu_s = now_s

    def _on_gps_path(self, msg: GpsPath) -> None:
        # position_x/y are the GPS producer's common ENU frame, independent
        # of the vehicle-frame points/header and the active CSV's local origin.
        # Align ENU to the existing parking map once, using measured body yaw.
        stamp_s = float(msg.reference_stamp.sec) + float(msg.reference_stamp.nanosec) * 1e-9
        frame_key = (('sequence', int(msg.route.sequence_id)) if msg.route.enabled
                     else ('single', msg.route.waypoint_csv))
        self.prior.update_gps_pose(
            int(msg.update),
            Pose2(float(msg.position_x), float(msg.position_y),
                  float(msg.vehicle_heading_rad)),
            stamp_s, self._clock_s(), int(msg.fix_quality),
            bool(msg.position_valid and msg.vehicle_heading_valid
                 and msg.heading_source == GpsPath.HEADING_FUSED),
            frame_key=frame_key,
            use_yaw_fallback=bool(self._p('gps.use_yaw_fallback')))
        if not bool(self._p('auto_trigger_gps_zone')):
            return
        if not msg.parking_zone:
            self.gps_zone_armed = True
            return
        if self.gps_zone_armed:
            self.gps_zone_armed = False
            mode_by_type = {
                GpsPath.PARKING_PERPENDICULAR: MODE_PERPENDICULAR,
                GpsPath.PARKING_PARALLEL: MODE_PARALLEL,
            }
            mode = mode_by_type.get(
                int(getattr(msg, 'parking_mode', GpsPath.PARKING_NONE)),
                str(self._p('gps_default_mode')))
            self._start_mission(
                mode,
                str(self._p('gps_default_side')),
                source='GpsPath.parking_zone:%s' % mode,
            )

    def _parse_command(self, command: str) -> tuple[str, str] | None:
        normalized = command.lower().strip()
        for token in (':', ',', '/', '_', '-'):
            normalized = normalized.replace(token, ' ')
        words = normalized.split()
        if not words:
            return None
        if words[0] in ('cancel', 'reset', 'stop'):
            self._cancel_search()
            self.get_logger().warn('parking mission cancelled by command')
            return None
        if words[0] == 'start':
            words = words[1:]
        mode = next((word for word in words if word in (
            MODE_PARALLEL, MODE_PERPENDICULAR, 't', '1', 't자', '1자')), None)
        side = next((word for word in words if word in (
            SIDE_LEFT, SIDE_RIGHT, SIDE_AUTO, '좌측', '우측', '양쪽')), None)
        if mode in ('t', 't자'):
            mode = MODE_PERPENDICULAR
        elif mode in ('1', '1자'):
            mode = MODE_PARALLEL
        if side == '좌측':
            side = SIDE_LEFT
        elif side == '우측':
            side = SIDE_RIGHT
        elif side == '양쪽':
            side = SIDE_AUTO
        if mode is None:
            return None
        # No side given -> search both and take whichever gap comes first
        # (user directive, 2026-09-02), not a fixed configured side.
        return mode, side or SIDE_AUTO

    def _on_command(self, msg: String) -> None:
        parsed = self._parse_command(msg.data)
        if parsed is None:
            if msg.data.lower().strip() not in ('cancel', 'reset', 'stop'):
                self.get_logger().error(
                    'invalid parking command: %r (use: start perpendicular right | '
                    'start parallel left | cancel)' % msg.data)
            return
        self._start_mission(parsed[0], parsed[1], source='command')

    def _cancel_search(self) -> None:
        self.mission.cancel()
        self.pipeline.return_to_mapping(self.slam.initialized)
        self.manual_gate_active = False
        self.search_running = False
        self.execution_authorized = False
        self.reference_input_stamp_s = -math.inf

    def _on_mission_command(self, msg: ParkingCommand) -> None:
        request_id = int(msg.request_id)
        if request_id <= 0 or request_id < self.search_request_id:
            return
        if msg.action == ParkingCommand.CANCEL:
            # Also tombstone a cancel that arrives before its prepare command.
            self.search_request_id = request_id
            self.search_mission_mode = int(msg.mission_mode)
            self._cancel_search()
            return
        if msg.action == ParkingCommand.PREPARE:
            if request_id == self.search_request_id:
                return  # retries and zone chatter never reset an existing search
            mode = {GpsPath.PARKING_PERPENDICULAR: MODE_PERPENDICULAR,
                    GpsPath.PARKING_PARALLEL: MODE_PARALLEL}.get(msg.mission_mode)
            if mode is None:
                return
            self._cancel_search()
            self.search_request_id = request_id
            self.search_mission_mode = int(msg.mission_mode)
            self.search_start_s = self._clock_s()
            self._start_mission(mode, SIDE_AUTO, source='mgm', force_reset=True)
            self.search_running = self.mission.state == MissionState.SCANNING
        elif (msg.action == ParkingCommand.ACTIVATE
              and request_id == self.search_request_id and self.search_running
              and int(msg.mission_mode) == self.search_mission_mode
              and self._preparation_ready(self._clock_s())):
            self.execution_authorized = True

    def _on_wall_status(self, msg: ParkingWallStatus) -> None:
        self.latest_wall_status = msg

    def _wall_acquired(self, now_s: float) -> bool:
        msg = getattr(self, 'latest_wall_status', None)
        if msg is None:
            return False
        stamp = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        return bool(msg.request_id == self.search_request_id and self.search_request_id > 0
                    and msg.mission_active and msg.complete and msg.frame_count >= 5
                    and 0 <= now_s - stamp <= .5)

    def _preparation_ready(self, now_s: float) -> bool:
        # Reuse existing pipeline, planner and localization freshness. Space
        # detection alone precedes the existing localization confirmation stage.
        return bool(
            self.search_running and self.pipeline.parking_enabled
            and self.mission.plan is not None and self.mission.space is not None
            and len(self.mission.current_path) > 0
            and self._localization_valid(now_s)
            and math.isfinite(self.reference_input_stamp_s)
            and 0.0 <= now_s - self.reference_input_stamp_s
            <= float(self._p('slam_stale_timeout_s')))

    def _start_mission(self, mode: str, side: str, source: str,
                       force_reset: bool = False) -> None:
        if self.search_running and source != 'mgm':
            self.get_logger().warn('manual/GPS trigger ignored during MGM request')
            return
        if mode not in (MODE_PARALLEL, MODE_PERPENDICULAR) or side not in (
            SIDE_LEFT, SIDE_RIGHT, SIDE_AUTO
        ):
            self.get_logger().error('invalid parking type/side: %s %s' % (mode, side))
            return
        if force_reset or bool(self._p('reset_map_on_mission_start')):
            self.slam.reset(Pose2())
            self.prior.reset(Pose2())
            self.pose_delta_tracker = PoseDeltaTracker()
            self.reference_input_stamp_s = -math.inf
            self.cloud_pairer.clear()
            self.pipeline.reset()
            self.last_icp_accepted_s = -math.inf
            self.last_icp_result = None
            self.last_slam_update_s = -math.inf
            self.latest_merged_cloud = None
            self.latest_scan_map = np.empty((0, 2), dtype=np.float64)
            self.latest_rear_clearance_m = None
            self.latest_rear_scan_s = -math.inf
            self.last_output = None
            self.slam_update_times.clear()
        accepted = self.mission.trigger(mode, side, self.slam.pose)
        if accepted:
            if source == 'command' and bool(self._p('manual_test_publish_gps_gate')):
                self.manual_gate_active = True
                self.gps_zone_armed = False
            self.get_logger().info(
                'parking mapping requested: mode=%s side=%s source=%s stage=%s '
                'map_points=%d' % (
                    mode, side, source, self.pipeline.stage.value,
                    len(self.slam.map)))
        else:
            self.get_logger().warn(
                'parking trigger ignored while state=%s' % self.mission.state.value)

    def _cloud_xy(self, msg: PointCloud2) -> np.ndarray:
        try:
            points = point_cloud2.read_points_numpy(
                msg, field_names=('x', 'y'), skip_nans=True)
            array = np.asarray(points)
            if array.dtype.names:
                return np.column_stack((array['x'], array['y'])).astype(np.float64)
            return np.asarray(array, dtype=np.float64).reshape((-1, 2))
        except (AttributeError, TypeError, ValueError, AssertionError):
            # AssertionError: read_points_numpy requires every field in the
            # message to share one datatype, not just the requested ones —
            # any publisher that mixes e.g. float32 xyz with an int32
            # intensity/index channel trips it. Fall back to the slower
            # per-point reader, which has no such restriction.
            return np.asarray([
                (float(point[0]), float(point[1]))
                for point in point_cloud2.read_points(
                    msg, field_names=('x', 'y'), skip_nans=True)
            ], dtype=np.float64).reshape((-1, 2))

    def _filter_cloud_points(self, points: np.ndarray) -> np.ndarray:
        points = np.asarray(points, dtype=np.float64).reshape((-1, 2))
        points = points[np.isfinite(points).all(axis=1)]
        if len(points) == 0:
            return points
        radius2 = np.einsum('ij,ij->i', points, points)
        valid = (
            radius2 >= float(self._p('cloud.min_range_m')) ** 2
        ) & (
            radius2 <= float(self._p('cloud.max_range_m')) ** 2
        )
        margin = float(self._p('cloud.self_filter_margin_m'))
        body = (
            (points[:, 0] >= -float(self._p('vehicle.rear_m')) - margin)
            & (points[:, 0] <= float(self._p('vehicle.front_m')) + margin)
            & (np.abs(points[:, 1])
               <= 0.5 * float(self._p('vehicle.width_m')) + margin)
        )
        return points[valid & ~body]

    def _on_merged_cloud(self, msg: PointCloud2) -> None:
        now_s = self._clock_s()
        frame_id = msg.header.frame_id.lstrip('/')
        if frame_id != self.base_frame.lstrip('/'):
            if now_s - self._last_frame_warning_s >= 5.0:
                self._last_frame_warning_s = now_s
                self.get_logger().error(
                    'merged cloud frame=%r rejected; expected calibrated %r.'
                    % (msg.header.frame_id, self.base_frame))
            return
        points = self._filter_cloud_points(self._cloud_xy(msg))
        self.latest_merged_cloud = StampedCloud(
            stamp_s=self._message_stamp_s(msg.header.stamp, now_s),
            receipt_s=now_s,
            frame_id=frame_id,
            points=points,
        )
        self.latest_front_cloud_s = now_s
        self.latest_rear_cloud_s = now_s

    def _on_front_cloud(self, msg: PointCloud2) -> None:
        self._on_sensor_cloud('front', msg)

    def _on_rear_cloud(self, msg: PointCloud2) -> None:
        self._on_sensor_cloud('rear', msg)

    def _on_sensor_cloud(self, sensor: str, msg: PointCloud2) -> None:
        now_s = self._clock_s()
        frame_id = msg.header.frame_id.lstrip('/')
        if frame_id != self.base_frame.lstrip('/'):
            if now_s - self._last_frame_warning_s >= 5.0:
                self._last_frame_warning_s = now_s
                self.get_logger().error(
                    '%s cloud frame=%r rejected; expected calibrated %r. '
                    'Set multi_lidar_fusion sensor_cloud_frame:=base_link.'
                    % (sensor, msg.header.frame_id, self.base_frame))
            return
        points = self._filter_cloud_points(self._cloud_xy(msg))
        stamp_s = self._message_stamp_s(msg.header.stamp, now_s)
        self.cloud_pairer.push(sensor, StampedCloud(
            stamp_s=stamp_s,
            receipt_s=now_s,
            frame_id=frame_id,
            points=points,
        ))
        if sensor == 'front':
            self.latest_front_cloud_s = now_s
        else:
            self.latest_rear_cloud_s = now_s

    def _process_slam(self) -> None:
        now_s = self._clock_s()
        if self._merged_mode:
            cloud = self.latest_merged_cloud
            if cloud is None or now_s - cloud.receipt_s > float(
                self._p('cloud.stale_timeout_s')
            ):
                return
            self.latest_merged_cloud = None  # consume once
            points, stamp_s = cloud.points, cloud.stamp_s
            self.last_pair_skew_s = 0.0
        else:
            pair = self.cloud_pairer.pop(
                now_s,
                float(self._p('cloud.sync_tolerance_s')),
                float(self._p('cloud.stale_timeout_s')),
            )
            if pair is None:
                return
            points, stamp_s = pair.points, pair.stamp_s
            self.last_pair_skew_s = pair.skew_s

        if self.search_running and (
                not math.isfinite(stamp_s) or stamp_s <= self.search_start_s):
            return  # queued pre-request scan cannot populate a new search map
        prior_pose = self.prior.predict(stamp_s)
        result = self.slam.update(
            points,
            prior_pose if (
                self.slam.config.map_correction_enabled
                or self.prior.last_status.velocity_fresh
                or self.prior.last_status.gps_corrected
            ) else None,
            update_map=self.pipeline.mapping_enabled,
        )
        self.last_icp_result = result
        self.last_slam_update_s = now_s
        self.slam_update_times.append(now_s)
        if result.accepted:
            self.last_icp_accepted_s = now_s
        self.pose_delta_tracker.update(result.pose)
        if result.accepted:
            self.reference_input_stamp_s = stamp_s
        # Localization is a control input, not a debug visualization. Publish
        # it at the configured SLAM rate (10Hz) so downstream preview/delta
        # generation is not silently throttled by debug_publish_rate_hz (5Hz).
        self._publish_slam_pose(self.get_clock().now().to_msg())
        prepared = voxel_downsample(points, 0.05)
        self.latest_scan_map = transform_points(prepared, result.pose)
        map_points = self.slam.map_points()
        previous_stage = self.pipeline.stage
        if self.pipeline.observe_slam(result.accepted, len(map_points)):
            self.get_logger().info(
                'parking pipeline: %s -> %s (accepted=%s map_points=%d)'
                % (previous_stage.value, self.pipeline.stage.value,
                   result.accepted, len(map_points)))

        if (
            self.pipeline.stage == PipelineStage.MAPPING
            and self.mission.state == MissionState.SCANNING
            and self.slam.initialized
            and result.accepted
        ):
            if self.mission.observe_map(map_points, result.pose):
                assert self.mission.plan is not None
                self.pipeline.plan_ready()
                self.get_logger().info(
                    'parking plan accepted; map frozen for localization: '
                    'mode=%s approach=%d reverse=%d confidence=%.2f'
                    % (
                        self.mission.plan.mode,
                        len(self.mission.plan.approach_path),
                        len(self.mission.plan.reverse_path),
                        self.mission.space.confidence if self.mission.space else 0.0,
                    ))
        if self.pipeline.stage == PipelineStage.PARKING:
            self.mission.observe_dynamic(self.latest_scan_map)
        debug_period = 1.0 / max(0.1, float(self._p('debug_publish_rate_hz')))
        if now_s - self.last_debug_publish_s >= debug_period:
            self.last_debug_publish_s = now_s
            self._publish_slam_debug(self.get_clock().now().to_msg())

    def _on_rear_scan(self, msg: LaserScan) -> None:
        center = math.radians(float(self._p('rear_scan_center_deg')))
        half = math.radians(float(self._p('rear_scan_half_width_deg')))
        offset = float(self._p('rear_range_offset_m'))
        values: list[float] = []
        for index, raw in enumerate(msg.ranges):
            angle = msg.angle_min + index * msg.angle_increment
            if abs(_angle_distance(angle, center)) > half:
                continue
            if not math.isfinite(raw) or raw < msg.range_min or raw > msg.range_max:
                continue
            corrected = float(raw) - offset
            if corrected > 0.0:
                values.append(corrected)
        minimum_points = int(self._p('rear_wall_min_points'))
        if len(values) < minimum_points:
            self.latest_rear_clearance_m = None
        else:
            values_array = np.asarray(values)
            candidate = float(np.percentile(values_array, 30.0))
            support = int(np.count_nonzero(
                np.abs(values_array - candidate)
                <= float(self._p('rear_wall_cluster_m'))))
            self.latest_rear_clearance_m = candidate if support >= minimum_points else None
        self.latest_rear_scan_s = self._clock_s()

    def _rear_clearance(self, now_s: float) -> Optional[float]:
        if now_s - self.latest_rear_scan_s > float(self._p('rear_scan_stale_timeout_s')):
            return None
        return self.latest_rear_clearance_m

    def _localization_valid(self, now_s: float) -> bool:
        if not self.slam.initialized:
            return False
        return now_s - self.last_icp_accepted_s <= float(self._p('slam_stale_timeout_s'))

    def _tick(self) -> None:
        now = self.get_clock().now()
        now_s = now.nanoseconds * 1.0e-9
        vehicle_speed = None
        if (
            self.latest_vehicle is not None
            and now_s - self.latest_vehicle_s
            <= float(self._p('prior.velocity_timeout_s'))
        ):
            vehicle_speed = float(self.latest_vehicle.v)
        if self.search_running and not self.execution_authorized:
            # Observe/map/plan in _process_slam, but do not advance approach,
            # reverse, wait or exit before ACTIVATE (MGM may already own PARKING).
            mission_output = MissionOutput(
                state=self.mission.state, space_found=False, path_blocked=False,
                done=False, reference_local=None, v_suggest_mps=0.0,
                progress_index=self.mission.progress, preview_index=0,
                status='mission_preparation')
        else:
            mission_output = self.mission.tick(
                self.slam.pose, now_s,
                rear_clearance_m=self._rear_clearance(now_s),
                vehicle_speed_mps=vehicle_speed,
                localization_valid=self._localization_valid(now_s),
            )
        output = mission_output
        if not self.pipeline.parking_enabled:
            output = MissionOutput(
                state=mission_output.state,
                space_found=False,
                path_blocked=False,
                done=False,
                reference_local=None,
                v_suggest_mps=0.0,
                progress_index=mission_output.progress_index,
                preview_index=mission_output.preview_index,
                status='%s:%s' % (
                    self.pipeline.stage.value, mission_output.status),
            )
        self.last_output = output
        if mission_output.state in (MissionState.COMPLETE, MissionState.IDLE):
            self.manual_gate_active = False
        self._publish_manual_gate(now.to_msg())
        self.stage_pub.publish(String(data=self.pipeline.stage.value))
        msg = ParkingStatus()
        msg.header.stamp = now.to_msg()
        msg.header.frame_id = self.base_frame
        msg.space_found = output.space_found
        msg.path_blocked = output.path_blocked
        msg.done = output.done
        # Keep cancelled/completed ID and mode visible for cleanup acknowledgement.
        msg.request_id = self.search_request_id
        msg.wall_acquisition_complete = self._wall_acquired(now_s)
        wall = getattr(self, 'latest_wall_status', None)
        msg.wall_acquisition_frames = wall.frame_count if wall is not None and wall.request_id == self.search_request_id else 0
        msg.search_active = self.search_running and mission_output.state not in (
            MissionState.IDLE, MissionState.COMPLETE)
        msg.search_space_found = bool(msg.search_active and self.mission.space is not None
                                      and self.mission.plan is not None)
        msg.preparation_ready = self._preparation_ready(now_s)
        if msg.preparation_ready:
            msg.preparation_stamp = Time(seconds=self.reference_input_stamp_s).to_msg()
        msg.mission_active = mission_output.state not in (
            MissionState.IDLE, MissionState.COMPLETE) and (
                not self.search_running or self.execution_authorized)
        msg.mission_mode = (
            GpsPath.PARKING_PARALLEL if self.mission.mode == MODE_PARALLEL
            else GpsPath.PARKING_PERPENDICULAR)
        if self.search_request_id:
            msg.mission_mode = self.search_mission_mode
        msg.v_suggest = float(output.v_suggest_mps)
        delta = self.pose_delta_tracker.delta
        msg.dx = float(delta.dx)
        msg.dy = float(delta.dy)
        msg.dyaw = float(delta.dyaw)
        msg.update = int(delta.update)
        if output.reference_local is not None:
            point = RefPoint()
            point.x = float(output.reference_local.x)
            point.y = float(output.reference_local.y)
            point.yaw = float(output.reference_local.yaw)
            point.curvature = float(output.reference_local.curvature)
            msg.points.append(point)
        self._set_reference_stamp(msg, now_s)
        self.status_pub.publish(msg)
        self._publish_paths(now.to_msg())
        self._publish_markers(now.to_msg(), output)
        self._publish_diagnostics(now.to_msg(), output, now_s)
        if (
            mission_output.state == MissionState.IDLE
            and self.pipeline.stage in (
                PipelineStage.LOCALIZATION, PipelineStage.PARKING)
        ):
            self.pipeline.return_to_mapping(self.slam.initialized)
            self.search_running = False
            self.execution_authorized = False

    def _set_reference_stamp(self, msg, now_s):
        # A timer-generated local preview still depends on the last accepted
        # localization sample. Rejected/absent ICP cannot rejuvenate its pose.
        stamp_s = self.reference_input_stamp_s
        if msg.points and math.isfinite(stamp_s) and stamp_s > 0.0 and self._localization_valid(now_s):
            msg.reference_stamp = Time(seconds=stamp_s).to_msg()

    def _publish_manual_gate(self, stamp) -> None:
        if self.manual_gate_pub is None:
            return
        msg = GpsPath()
        msg.header.stamp = stamp
        msg.header.frame_id = self.base_frame
        msg.parking_zone = self.manual_gate_active
        msg.parking_mode = (
            GpsPath.PARKING_PARALLEL
            if self.mission.mode == MODE_PARALLEL
            else GpsPath.PARKING_PERPENDICULAR)
        # A neutral one-metre point keeps the existing GpsPath freshness/data
        # contract valid before MGM changes into PARKING. It is never selected
        # as the parking path.
        point = RefPoint()
        point.x = 1.0
        point.y = 0.0
        point.yaw = 0.0
        point.curvature = 0.0
        msg.points.append(point)
        msg.fix_quality = 1
        msg.heading_source = GpsPath.HEADING_TANGENT
        self.manual_gate_pub.publish(msg)

    def _header(self, stamp) -> Header:
        header = Header()
        header.stamp = stamp
        header.frame_id = self.map_frame
        return header

    def _publish_slam_pose(self, stamp) -> None:
        header = self._header(stamp)
        pose = PoseStamped()
        pose.header = header
        pose.pose.position.x = float(self.slam.pose.x)
        pose.pose.position.y = float(self.slam.pose.y)
        qz, qw = _quaternion_z(self.slam.pose.yaw)
        pose.pose.orientation.z = qz
        pose.pose.orientation.w = qw
        self.pose_pub.publish(pose)

    def _publish_slam_debug(self, stamp) -> None:
        header = self._header(stamp)
        pose_text = Marker()
        pose_text.header = header
        pose_text.ns = 'slam_pose'
        pose_text.id = 0
        pose_text.type = Marker.TEXT_VIEW_FACING
        pose_text.action = Marker.ADD
        pose_text.pose.position.x = float(self.slam.pose.x)
        pose_text.pose.position.y = float(self.slam.pose.y)
        pose_text.pose.position.z = 0.45
        pose_text.pose.orientation.w = 1.0
        pose_text.scale.z = 0.22
        pose_text.color.r = 1.0
        pose_text.color.g = 1.0
        pose_text.color.b = 0.15
        pose_text.color.a = 1.0
        pose_text.text = (
            '%s\nx: %.3f m\ny: %.3f m\nyaw: %.1f deg (%.3f rad)'
            % (
                self.pipeline.stage.value.upper(), self.slam.pose.x,
                self.slam.pose.y, math.degrees(self.slam.pose.yaw),
                self.slam.pose.yaw,
            )
        )
        self.pose_text_pub.publish(pose_text)
        self.scan_pub.publish(point_cloud2.create_cloud_xyz32(
            header,
            [(float(x), float(y), 0.0) for x, y in self.latest_scan_map],
        ))
        map_points = self.slam.map_points()
        self.map_pub.publish(point_cloud2.create_cloud_xyz32(
            header,
            [(float(x), float(y), 0.0) for x, y in map_points],
        ))

    def _path_message(self, path_points, stamp) -> Path:
        msg = Path()
        msg.header = self._header(stamp)
        for point in path_points:
            pose = PoseStamped()
            pose.header = msg.header
            pose.pose.position.x = float(point.x)
            pose.pose.position.y = float(point.y)
            qz, qw = _quaternion_z(point.yaw)
            pose.pose.orientation.z = qz
            pose.pose.orientation.w = qw
            msg.poses.append(pose)
        return msg

    def _publish_paths(self, stamp) -> None:
        self.path_pub.publish(self._path_message(self.mission.debug_path(), stamp))
        self.active_path_pub.publish(self._path_message(self.mission.current_path, stamp))

    def _publish_markers(self, stamp, output: MissionOutput) -> None:
        array = MarkerArray()
        delete = Marker()
        delete.header = self._header(stamp)
        delete.action = Marker.DELETEALL
        array.markers.append(delete)

        if self.mission.space is not None:
            space = self.mission.space
            side_sign = 1.0 if space.side == SIDE_LEFT else -1.0
            corners_lane = [
                (space.start_x_lane, 0.0),
                (space.end_x_lane, 0.0),
                (space.end_x_lane, side_sign * space.side_distance_m),
                (space.start_x_lane, side_sign * space.side_distance_m),
                (space.start_x_lane, 0.0),
            ]
            c = math.cos(space.lane_pose_map.yaw)
            s = math.sin(space.lane_pose_map.yaw)
            marker = Marker()
            marker.header = self._header(stamp)
            marker.ns = 'space'
            marker.id = 1
            marker.type = Marker.LINE_STRIP
            marker.action = Marker.ADD
            marker.scale.x = 0.045
            marker.color.r = 0.1
            marker.color.g = 0.9
            marker.color.b = 0.2
            marker.color.a = 1.0
            for x, y in corners_lane:
                point = Point()
                point.x = space.lane_pose_map.x + c * x - s * y
                point.y = space.lane_pose_map.y + s * x + c * y
                marker.points.append(point)
            array.markers.append(marker)

        if self.mission.plan is not None:
            for marker_id, pose_value, color in (
                (2, self.mission.plan.stage_pose_map, (1.0, 0.65, 0.0)),
                (3, self.mission.plan.goal_pose_map, (0.0, 0.7, 1.0)),
            ):
                marker = Marker()
                marker.header = self._header(stamp)
                marker.ns = 'poses'
                marker.id = marker_id
                marker.type = Marker.ARROW
                marker.action = Marker.ADD
                marker.pose.position.x = pose_value.x
                marker.pose.position.y = pose_value.y
                qz, qw = _quaternion_z(pose_value.yaw)
                marker.pose.orientation.z = qz
                marker.pose.orientation.w = qw
                marker.scale.x = 0.45
                marker.scale.y = 0.10
                marker.scale.z = 0.10
                marker.color.r, marker.color.g, marker.color.b = color
                marker.color.a = 1.0
                array.markers.append(marker)

        if output.reference_local is not None:
            ref = output.reference_local
            c = math.cos(self.slam.pose.yaw)
            s = math.sin(self.slam.pose.yaw)
            marker = Marker()
            marker.header = self._header(stamp)
            marker.ns = 'preview'
            marker.id = 4
            marker.type = Marker.SPHERE
            marker.action = Marker.ADD
            marker.pose.position.x = self.slam.pose.x + c * ref.x - s * ref.y
            marker.pose.position.y = self.slam.pose.y + s * ref.x + c * ref.y
            marker.pose.orientation.w = 1.0
            marker.scale.x = marker.scale.y = marker.scale.z = 0.16
            marker.color.r = 1.0
            marker.color.g = 0.1
            marker.color.b = 0.8
            marker.color.a = 1.0
            array.markers.append(marker)

        text = Marker()
        text.header = self._header(stamp)
        text.ns = 'status'
        text.id = 5
        text.type = Marker.TEXT_VIEW_FACING
        text.action = Marker.ADD
        text.pose.position.x = self.slam.pose.x
        text.pose.position.y = self.slam.pose.y
        text.pose.position.z = 0.7
        text.scale.z = 0.22
        text.color.r = text.color.g = text.color.b = text.color.a = 1.0
        text.text = (
            '%s | mission=%s | v=%.2f\n'
            'x=%.3f m  y=%.3f m  yaw=%.1f deg'
            % (
                self.pipeline.stage.value.upper(), output.state.value,
                output.v_suggest_mps, self.slam.pose.x, self.slam.pose.y,
                math.degrees(self.slam.pose.yaw),
            )
        )
        array.markers.append(text)
        self.marker_pub.publish(array)

    def _publish_diagnostics(self, stamp, output: MissionOutput, now_s: float) -> None:
        array = DiagnosticArray()
        array.header.stamp = stamp
        status = DiagnosticStatus()
        status.name = 'stack_parking/pipeline'
        status.hardware_id = 'front_rear_lidar'
        localization_ok = self._localization_valid(now_s)
        cloud_timeout = float(self._p('cloud.stale_timeout_s'))
        front_age = now_s - self.latest_front_cloud_s
        rear_age = now_s - self.latest_rear_cloud_s
        clouds_ok = front_age <= cloud_timeout and rear_age <= cloud_timeout
        status.level = DiagnosticStatus.OK
        if not clouds_ok:
            status.level = DiagnosticStatus.ERROR
        elif (
            not localization_ok
            and self.pipeline.stage in (
                PipelineStage.LOCALIZATION, PipelineStage.PARKING)
        ):
            status.level = DiagnosticStatus.ERROR
        elif output.path_blocked or self.mission.last_plan_error:
            status.level = DiagnosticStatus.WARN
        status.message = output.status
        icp = self.last_icp_result
        rear = self._rear_clearance(now_s)
        slam_hz = 0.0
        if len(self.slam_update_times) >= 2:
            duration = self.slam_update_times[-1] - self.slam_update_times[0]
            if duration > 0.0:
                slam_hz = (len(self.slam_update_times) - 1) / duration
        prior = self.prior.last_status
        tentative_cells, confirmed_cells = self.slam.map.state_counts()
        values = {
            'pipeline_stage': self.pipeline.stage.value,
            'mission_state': output.state.value,
            'mode': self.mission.mode,
            'side': self.mission.side,
            'slam_pose': '%.3f %.3f %.3f' % (
                self.slam.pose.x, self.slam.pose.y, self.slam.pose.yaw),
            'slam_valid': str(localization_ok),
            'icp_accepted': str(bool(icp.accepted) if icp else False),
            'icp_reason': icp.reason if icp else 'no_scan_yet',
            'map_correction_enabled': str(self.slam.config.map_correction_enabled),
            'unobserved_delete_misses': str(self.slam.config.unobserved_delete_misses),
            'icp_rmse_m': ('%.4f' % icp.rmse_m) if icp and math.isfinite(icp.rmse_m) else 'inf',
            'icp_matches': str(icp.correspondences if icp else 0),
            'map_points': str(len(self.slam.map)),
            'map_tentative_cells': str(tentative_cells),
            'map_confirmed_cells': str(confirmed_cells),
            'map_updates_enabled': str(self.pipeline.mapping_enabled),
            'slam_rate_hz': '%.2f' % slam_hz,
            'slam_rate_target_hz': str(float(self._p('slam_rate_hz'))),
            'front_cloud_age_s': (
                'inf' if not math.isfinite(front_age) else '%.3f' % front_age),
            'rear_cloud_age_s': (
                'inf' if not math.isfinite(rear_age) else '%.3f' % rear_age),
            'pair_skew_s': (
                'inf' if not math.isfinite(self.last_pair_skew_s)
                else '%.4f' % self.last_pair_skew_s),
            'cloud_pairs': str(self.cloud_pairer.pairs),
            'cloud_stale_drops': str(self.cloud_pairer.stale_drops),
            'cloud_sync_drops': str(self.cloud_pairer.sync_drops),
            'motion_prior_source': prior.source,
            'velocity_fresh': str(prior.velocity_fresh),
            'steering_fresh': str(prior.steering_fresh),
            'steering_ros_deg': '%.3f' % math.degrees(prior.steering_rad),
            'bicycle_yaw_rate_deg_s': (
                '%.3f' % math.degrees(prior.yaw_rate_rad_s)),
            'vehicle_vector_age_s': (
                'inf' if not math.isfinite(now_s - self.latest_vehicle_s)
                else '%.3f' % (now_s - self.latest_vehicle_s)),
            'imu_fresh': str(prior.imu_fresh),
            'imu_topic_age_s': (
                'inf' if not math.isfinite(now_s - self.latest_imu_s)
                else '%.3f' % (now_s - self.latest_imu_s)),
            'gps_input_frame': 'ENU: x=east y=north yaw=CCW_from_east',
            'gps_map_alignment': (
                'unanchored' if self.prior.gps_map_transform is None else
                'x=%.3f y=%.3f yaw_deg=%.3f' % (
                    self.prior.gps_map_transform.x, self.prior.gps_map_transform.y,
                    math.degrees(self.prior.gps_map_transform.yaw))),
            'gps_position_corrected': str(prior.gps_corrected),
            'gps_innovation_m': (
                'inf' if not math.isfinite(prior.gps_innovation_m)
                else '%.3f' % prior.gps_innovation_m),
            'rear_clearance_m': 'invalid' if rear is None else '%.3f' % rear,
            'path_blocked_dynamic_only': str(output.path_blocked),
            'progress': '%d/%d' % (output.progress_index, len(self.mission.current_path)),
            'preview_distance_m': str(float(self._p('preview_distance_m'))),
            'plan_error': self.mission.last_plan_error,
        }
        status.values = [KeyValue(key=key, value=value) for key, value in values.items()]
        array.status.append(status)
        self.diagnostic_pub.publish(array)


def main(args=None):
    rclpy.init(args=args)
    node = StackParkingNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()


if __name__ == '__main__':
    main()
